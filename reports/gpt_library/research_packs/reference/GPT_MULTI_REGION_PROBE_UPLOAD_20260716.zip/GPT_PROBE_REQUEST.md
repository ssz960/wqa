# GPT Probe Request

Use the attached current context and selected datasets to perform a read-only capability probe.

## Phase 1: Field Recall

For each theme below, retrieve 10-20 fields from the selected dataset files. Return field id, dataset, type, description, coverage, region, and delay. Do not invent fields.

- analyst earnings revision / surprise
- point-in-time fundamental quality
- model output / forecast
- news sentiment
- price-volume baseline

## Phase 2: Expression Compatibility

For each theme, propose up to 3 expression skeletons using only operators listed in `reports/data_fields/gpt_factor_context_current.md`. Check MATRIX, VECTOR, GROUP, and scalar compatibility before producing an expression.

## Phase 3: Settings and Batch Probe

- Use one locked settings key at a time.
- Validate Region, Universe, Delay, Neutralization, Language, and test period against `probe/region_settings_current.md`.
- Build a dry-run parent/child plan of at most 8 parents x 10 REGULAR children.
- Do not submit, backtest, write points, or pad a short parent.
- Report which candidates would fall back to the retained 3-slot `legacy_single` lane.

## Expected Output

Return a compact table of selected fields, expression skeletons, rejected combinations, settings key, estimated operator count, and whether the candidate is `MULTI_ELIGIBLE`, `SINGLE_FALLBACK`, or `REJECTED`. This is a research probe, not an execution request.
