﻿# GPT Probe Context - Partial Dataset Package

This is a bounded first probe package. It contains all current operator definitions and the live settings capability, but only eight selected datasets. The authoritative full registry remains outside this package at `reports/data_fields/available_data_fields_current.csv`.

Selected field count: 10,907
Selected datasets: ai_equity_alpha, ai_news_scores, analyst4, analyst15, fundamental6, fundamental23, model77, pv1

## Settings Capability

- decay (Decay): integer [0, 512]
- delay (Delay): instrumentType/EQUITY/region/USA=[1, 0]; instrumentType/EQUITY/region/GLB=[1]; instrumentType/EQUITY/region/EUR=[1, 0]; instrumentType/EQUITY/region/ASI=[1]; instrumentType/EQUITY/region/CHN=[0, 1]; instrumentType/EQUITY/region/JPN=[1, 0]; instrumentType/EQUITY/region/IND=[1]; instrumentType/EQUITY/region/MEA=[1]
- instrumentType (Instrument type): EQUITY
- language (Language): PYTHON, FASTEXPR
- lookback (Lookback): integer [0, 1024]
- maxPosition (Max position): OFF, ON
- maxTrade (Max trade): OFF, ON
- nanHandling (Nan handling): ON, OFF
- neutralization (Neutralization): instrumentType/EQUITY/region/USA=[NONE, REVERSION_AND_MOMENTUM, STATISTICAL, CROWDING, FAST, SLOW, MARKET, SECTOR, INDUSTRY, SUBINDUSTRY, SLOW_AND_FAST]; instrumentType/EQUITY/region/GLB=[NONE, REVERSION_AND_MOMENTUM, STATISTICAL, CROWDING, FAST, SLOW, MARKET, SECTOR, INDUSTRY, SUBINDUSTRY, COUNTRY, SLOW_AND_FAST]; instrumentType/EQUITY/region/EUR=[NONE, REVERSION_AND_MOMENTUM, STATISTICAL, CROWDING, FAST, SLOW, MARKET, SECTOR, INDUSTRY, SUBINDUSTRY, COUNTRY, SLOW_AND_FAST]; instrumentType/EQUITY/region/ASI=[NONE, REVERSION_AND_MOMENTUM, STATISTICAL, CROWDING, FAST, SLOW, MARKET, SECTOR, INDUSTRY, SUBINDUSTRY, COUNTRY, SLOW_AND_FAST]; instrumentType/EQUITY/region/CHN=[NONE, REVERSION_AND_MOMENTUM, STATISTICAL, CROWDING, FAST, SLOW, MARKET, SECTOR, INDUSTRY, SUBINDUSTRY, SLOW_AND_FAST]; instrumentType/EQUITY/region/JPN=[NONE, REVERSION_AND_MOMENTUM, STATISTICAL, CROWDING, FAST, SLOW, MARKET, SECTOR, INDUSTRY, SUBINDUSTRY, SLOW_AND_FAST]; instrumentType/EQUITY/region/IND=[NONE, REVERSION_AND_MOMENTUM, STATISTICAL, CROWDING, FAST, SLOW, MARKET, SECTOR, INDUSTRY, SUBINDUSTRY, SLOW_AND_FAST]; instrumentType/EQUITY/region/MEA=[NONE, MARKET, SECTOR, INDUSTRY, SUBINDUSTRY, COUNTRY]
- pasteurization (Pasteurization): ON, OFF
- region (Region): instrumentType/EQUITY=[USA, GLB, EUR, ASI, CHN, JPN, IND, MEA]
- selectionHandling (Selection handling): POSITIVE, NON_ZERO, NON_NAN
- selectionLimit (Selection limit): integer [10, 1000]
- testPeriod (Test period): string [P0Y0M0D, P6Y0M0D]
- truncation (Truncation): float [0, 1]
- unitHandling (Unit handling): VERIFY
- universe (Universe): instrumentType/EQUITY/region/USA=[TOP3000, TOP2000, TOP1000, TOP500, TOP200, ILLIQUID_MINVOL1M, TOPSP500]; instrumentType/EQUITY/region/GLB=[TOP3000, MINVOL1M, MINVOL10M, TOPDIV3000]; instrumentType/EQUITY/region/EUR=[TOP2500, TOP1200, TOP800, TOP400, ILLIQUID_MINVOL1M, TOPCS1600]; instrumentType/EQUITY/region/ASI=[MINVOL1M, MINVOL10M, ILLIQUID_MINVOL1M, TOP500]; instrumentType/EQUITY/region/CHN=[TOP2000U]; instrumentType/EQUITY/region/JPN=[TOP1600, TOP1200]; instrumentType/EQUITY/region/IND=[TOP500]; instrumentType/EQUITY/region/MEA=[TOP400, TOP300]
- visualization (Visualization): boolean

### Captured UI Default Profile

- Source: VISIBLE_BRAIN_UI_BASELINE_20260716
- instrumentType: EQUITY
- region: USA
- universe: TOP3000
- delay: 1
- neutralization: SUBINDUSTRY
- decay: 4
- truncation: 0.08
- pasteurization: ON
- unitHandling: VERIFY
- nanHandling: OFF
- testPeriod: P1Y0M0D
- maxTrade: OFF
- maxPosition: OFF

## Operators

- Count: 85

### Arithmetic

- `abs(x)`: Returns the absolute value of a number, removing any negative sign.
- `add(x, y, filter = false), x + y`: Adds two or more inputs element wise. Set filter=true to treat NaNs as 0 before summing.
- `densify(x)`: Converts a grouping field of many buckets into lesser number of only available buckets so as to make working with grouping fields computationally efficient
- `divide(x, y), x / y`: Returns x divided by y (x / y). Note: dividing by zero raises an error; to avoid it, use divide(x, add(y, 0.0001)); adding a small epsilon to the denominator prevents divide-by-zero errors.
- `inverse(x)`: Returns the reciprocal of x (1 / x). Note: errors when x = 0; to avoid it, use inverse(add(x, 0.0001)); adding a small epsilon prevents divide-by-zero errors.
- `log(x)`: Calculates the natural logarithm of the input value. Commonly used to transform data that has positive values.
- `max(x, y, ..)`: Maximum value of all inputs. At least 2 inputs are required
- `min(x, y ..)`: Minimum value of all inputs. At least 2 inputs are required
- `multiply(x ,y, ... , filter=false), x * y`: Multiplies two or more inputs element wise. Set filter=true to treat NaNs as 0 before multiplication
- `power(x, y)`: Returns x raised to the power of y (x ^ y). Note: power(x, y) can drop the sign of x when y is non-integer; use signed_power(x, y) to preserve the sign of x.
- `reverse(x)`: 聽- x
- `sigmoid(x)`: Returns 1 / (1 + exp(-x))
- `sign(x)`: Returns the sign of a number: +1 for positive, -1 for negative, and 0 for zero. If the input is NaN, returns NaN.



Input: Value of 7 instruments at day t: (2, -3, 5, 6, 3, NaN, -10)

Output: (1, -1, 1, 1, 1, NaN, -1)
- `signed_power(x, y)`: x raised to the power of y such that final result preserves sign of x
- `sqrt(x)`: Returns the non-negative square root of x. Equivalent to power(x, 0.5). Note: for x < 0 the result is undefined; to retain the sign of x, use signed_power(x, 0.5) instead.
- `subtract(x, y, filter=false), x - y`: Subtracts inputs left to right: x ? y ? 鈥?Supports two or more inputs. Set filter=true to treat NaNs as 0 before subtraction.
- `tanh(x)`: Hyperbolic tangent of x

### Cross Sectional

- `normalize(x, useStd = false, limit = 0.0)`: Centers a daily cross section by subtracting the market mean; optionally divide by the cross sectional standard deviation and clamp the result to [?limit, +limit]. NaNs are ignored in mean/std.
- `quantile(x, driver = gaussian, sigma = 1.0)`: Ranks and shifts a vector of Alpha values, then applies a chosen statistical distribution (gaussian, cauchy, or uniform) to reduce outliers. The sigma parameter controls the scale of the output.
- `rank(x, rate=2)`: Ranks the values of the input x among all instruments, returning numbers evenly spaced between 0.0 and 1.0. Useful for normalizing data and reducing the impact of outliers.
- `regression_proj(y, x)`: Conducts the cross-sectional regression on the stocks with Y as target and X as the independent variable
- `scale(x, scale=1, longscale=1, shortscale=1)`: Scales the input so that the sum of absolute values across all instruments equals a specified book size. Allows separate scaling for long and short positions using optional parameters.
- `vector_neut(x, y)`: For given vectors x and y, it finds a new vector x* (output) such that x* is orthogonal to y
- `vector_proj(x, y)`: Returns vector projection of x onto y.
- `winsorize(x, std=4)`: Winsorize limits values in a data to within a specified number of standard deviations from the mean, reducing the impact of extreme outliers. Note: recommended std values range from 2 to 5: std = 2, 3, 4, 5 removes approximately 4.5%, 0.27%, 0.01%, and 0.0001% of extreme values, respectively (higher std removes fewer extremes).
- `zscore(x)`: Z-score is a numerical measurement that describes a value's relationship to the mean of a group of values. Z-score is measured in terms of standard deviations from the mean

### Group

- `group_backfill(x, group, d, std = 4.0)`: Fills missing (NaN) values for instruments within the same group by calculating a winsorized mean of all non-NaN values over the past d days. The winsorized mean is computed by trimming extreme values based on a specified standard deviation multiplier (std, default 4.0).
- `group_cartesian_product(g1, g2)`: Merge two groups into one group. If originally there are len_1 and len_2 group indices in g1 and g2, there will be len_1 * len_2 indices in the new group.
- `group_extra(x, weight, group)`: Replaces NaN values by their corresponding group means.
- `group_mean(x, weight, group)`: Calculates the harmonic mean of a data field within each specified group.
- `group_neutralize(x, group)`: Neutralizes Alpha values within each specified group by subtracting the group mean from each value. Groups can be industry, sector, country, or any custom grouping.
- `group_rank(x, group)`: Ranks each element within its group based on the input field, assigning a value between 0.0 and 1.0. This helps compare items within the same group, such as stocks in the same industry.
- `group_scale(x, group)`: Normalizes values within each group to a range between 0 and 1, making data comparable across different groups.
- `group_zscore(x, group)`: Calculates the Z-score of each value within its group, showing how far each value is from the group mean in terms of standard deviations. Useful for comparing values relative to their group.

### Logical

- `and(input1, input2)`: Returns 1 ('true') if both inputs are 1 ('true'). Otherwise, returns 0 ('false').
- `input1 == input2`: Returns 1 ('true') if input1 and input2 are the same. Otherwise, returns 0 ('false').
- `input1 > input2`: Returns 1 ('true') if input1 is a larger than input2. Otherwise, returns 0 ('false').
- `input1 >= input2`: Returns 1 ('true') if input1 is a larger or the same as input2. Otherwise, returns 0 ('false').
- `if_else(input1, input2, input 3)`: The if_else operator returns one of two values based on a condition. If the condition is true, it returns the first value; if false, it returns the second value.
- `is_nan(input)`: If (input == NaN) return 1 else return 0
- `input1 < input2`: Returns 1 ('true') if input1 is a smaller than input2. Otherwise, returns 0 ('false').
- `input1 <= input2`: Returns 1 ('true') if input1 is a smaller or the same as input2. Otherwise, returns 0 ('false').
- `not(x)`: Returns the logical negation of x. Returns 0 when x is 1 (鈥榯rue鈥? and 1 when x is 0 (鈥榝alse鈥?.
- `input1!= input2`: Returns 1 ('true') if input1 and input2 are different numbers. Otherwise, returns 0 ('false').
- `or(input1, input2)`: Returns 1 if either input is true (either input1 or input2 has a value of 1), otherwise it returns 0.

### Special

- `inst_pnl(x)`: Generate pnl per instruments. Please note that the use of the inst_pnl() operator in an Alpha Expression is considered as utilizing the pv1 dataset (Price Volume Data for Equity) since it relies on pv1 data for calculations.

### Time Series

- `days_from_last_change(x)`: Calculates the number of days since the last change in the value of a given variable.
- `hump(x, hump = 0.01)`: Limits amount and magnitude of changes in input (thus reducing turnover)
- `kth_element(x, d, k, ignore=鈥淣aN鈥?`: Returns the K-th value from a time series by looking back over a specified number of (鈥榙鈥? days, with the option to ignore certain values. Commonly used for backfilling missing data.
- `last_diff_value(x, d)`: Returns the most recent value of x from the past d days that is different from the current value of x.
- `ts_arg_max(x, d)`: Returns the number of days since the maximum value occurred in the last d days of a time series. If today's value is the maximum, returns 0; if it was yesterday, returns 1, and so on.
- `ts_arg_min(x, d)`: Returns the number of days since the minimum value occurred in a time series over the past d days. If today's value is the minimum, returns 0; if it was yesterday, returns 1, and so on.
- `ts_av_diff(x, d)`: Calculates the difference between a value and its mean over a specified period, ignoring NaN values in the mean calculation. In short, it returns x 鈥?ts_mean(x, d) with NaNs ignored.
- `ts_backfill(x,lookback = d, k=1)`: Replaces missing (NaN) values in a time series with the most recent valid value from a specified lookback window, improving data coverage and reducing risk from missing data.
- `ts_corr(x, y, d)`: Calculates the Pearson correlation between two variables, x and y, over the past d days, showing how closely they move together.
- `ts_count_nans(x ,d)`: Counts the number of missing (NaN) values in a data series over a specified number of days.
- `ts_covariance(y, x, d)`: Calculates the covariance between two time-series variables, y and x, over the past d days. Useful for measuring how two variables move together within a specified historical window.
- `ts_decay_linear(x, d, dense = false)`: Applies a linear decay to time-series data over a set number of days, smoothing the data by averaging recent values and reducing the impact of older or missing data.
- `ts_delay(x, d)`: Returns the value of a variable x from d days ago. Use this operator to access historical data points by specifying the desired time lag in days.
- `ts_delta(x, d)`: Calculates the difference between a value and its delayed version over a specified period. Useful for measuring changes or momentum in time-series data.
- `ts_entropy(x,d)`: For each instrument, we collect values of input in the past d days and calculate the probability distribution then the information entropy via a histogram as a result
- `ts_mean(x, d)`: Calculates the simple average (mean) value of a variable x over the past d days.
- `ts_min_diff(x, d)`: Returns x - ts_min(x, d)
- `ts_min_max_cps(x, d, f = 2)`: Returns (ts_min(x, d) + ts_max(x, d)) - f * x. If not specified, by default f = 2
- `ts_min_max_diff(x, d, f = 0.5)`: Returns x - f * (ts_min(x, d) + ts_max(x, d)). If not specified, by default f = 0.5
- `ts_product(x, d)`: Returns the product of the values of x over the past d days. Useful for calculating geometric means and compounding returns or growth rates.
- `ts_quantile(x,d, driver="gaussian" )`: Calculates the ts_rank of the input and transforms it using the inverse cumulative distribution function (quantile function) of a specified probability distribution (default: Gaussian/normal). This helps to normalize or reshape the distribution of your data over a rolling window.
- `ts_rank(x, d, constant = 0)`: Ranks the value of a variable for each instrument over a specified number of past days, returning the rank of the current value (optionally adjusted by a constant). Useful for normalizing time-series data and highlighting relative performance over time.
- `ts_regression(y, x, d, lag = 0, rettype = 0)`: Returns various parameters related to regression function
- `ts_scale(x, d, constant = 0)`: Scales a time series to a 0鈥? range based on its minimum and maximum values over a specified period, with an optional constant shift.
- `ts_skewness(x, d)`: Return skewness of x for the past d days
- `ts_std_dev(x, d)`: Calculates the standard deviation of a data series x over the past d days, measuring how much the values deviate from their mean during that period.
- `ts_step(1)`: Returns a counter of days, incrementing by one each day.
- `ts_sum(x, d)`: Sum values of x for the past d days.
- `ts_target_tvr_decay(x, lambda_min=0, lambda_max=1, target_tvr=0.1)`: Tune "ts_decay" to have a turnover equal to a certain target, with optimization weight range between lambda_min, lambda_max
- `ts_zscore(x, d)`: Calculates the Z-score of a time series, showing how far today's value is from the recent average, measured in standard deviations. Useful for standardizing and comparing values over time.

### Transformational

- `bucket(rank(x), range=鈥?, 1, 0.1鈥? skipBoth=False, NaNGroup=False)

or

bucket(rank(x), buckets = 鈥?,5,6,7,10鈥? skipBoth=False, NaNGroup=False)`: The bucket operator creates custom groups by dividing data into buckets (ranges) based on ranked values of any data field. These buckets can then be used with group operators like group_neutralize, group_rank, group_zscore etc.
- `trade_when(x, y, z)`: The trade_when operator changes Alpha values only when a specific condition is met, keeps previous values otherwise, and can close positions by assigning NaN under an exit condition. It is useful for reducing turnover and controlling when trades are executed.

### Vector

- `vec_avg(x)`: Calculates the mean (average) of all elements in a vector field for each instrument and date, converting vector data to a single matrix value.
- `vec_count(x)`: Number of elements in vector field x
- `vec_max(x)`: Maximum value form vector field x
- `vec_min(x)`: Minimum value form vector field x
- `vec_range(x)`: Difference between maximum and minimum element in vector field x
- `vec_stddev(x)`: Standard Deviation of vector field x
- `vec_sum(x)`: Calculates the sum of all values in a vector field.

## Recommended GPT Retrieval Contract

1. Lock the simulation settings first and reject fields outside the locked scope.
2. Select one or two datasets or a narrow category; do not search the full registry in the prompt.
3. Retrieve candidate fields with field_id, description, type, coverage, and dataset provenance.
4. Select only operators valid for the expression language and compatible with the selected field types.
5. Generate factor expressions, then run syntax / operator-count / setting validation before any backtest.
