# Consultant Multi 80-Slot Probe Rules

Source: `consultant_capability_profile.json` plus the current `consultant_multi_8x10_implementation_report.md`, 2026-07-16. The profile retains its original `PARTIAL` / `USER_CONFIRMED_NEEDS_RUNTIME_PROBE` provenance; the implementation report contains the later runtime/watchdog evidence.

## Capacity

- Transport profile: `consultant_multi`
- Maximum concurrent parent batches: `8`
- Children per parent: exactly `10` REGULAR children
- Nominal child capacity: `8 x 10 = 80`
- Daily candidate cap: `5000` children
- Day boundary: `America/New_York`
- Budget count basis: child
- Children within one parent must share the same compatibility settings key.

## Required Ledger and Gates

- Capability snapshot must be present and valid.
- Parent and child request hashes must be deterministic and auditable.
- Budget reservations and submitted-child counts must reconcile.
- Unknown budget, unknown billing semantics, missing parent/child reconciliation, or profile inconsistency fails closed.
- A short compatible group below 10 does not pad a parent; it uses the single fallback lane.
- Keep `legacy_single` with exactly 3 configured slots as the immediate rollback path.

## Safety Boundary

This file describes the current validated production capacity and probe constraints. It is not permission for GPT to submit simulations or alphas. GPT may use it to validate batch sizing, settings compatibility, and fallback behavior only. No alpha submission or Osmosis point write is part of this probe.
