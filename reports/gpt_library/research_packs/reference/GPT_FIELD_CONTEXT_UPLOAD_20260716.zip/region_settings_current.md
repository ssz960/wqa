# Current Region and Simulation Settings Probe

Source: read-only `OPTIONS /simulations` capability response captured on 2026-07-16. No simulation POST was issued.

## Regions

`USA`, `GLB`, `EUR`, `ASI`, `CHN`, `JPN`, `IND`, `MEA`

## Universe by Region

- USA: `TOP3000`, `TOP2000`, `TOP1000`, `TOP500`, `TOP200`, `ILLIQUID_MINVOL1M`, `TOPSP500`
- GLB: `TOP3000`, `MINVOL1M`, `MINVOL10M`, `TOPDIV3000`
- EUR: `TOP2500`, `TOP1200`, `TOP800`, `TOP400`, `ILLIQUID_MINVOL1M`, `TOPCS1600`
- ASI: `MINVOL1M`, `MINVOL10M`, `ILLIQUID_MINVOL1M`, `TOP500`
- CHN: `TOP2000U`
- JPN: `TOP1600`, `TOP1200`
- IND: `TOP500`
- MEA: `TOP400`, `TOP300`

## Delay by Region

- `D0`: USA, EUR, CHN, JPN
- `D1`: USA, GLB, EUR, ASI, CHN, JPN, IND, MEA

## Neutralization by Region

- USA / CHN / JPN / IND: `NONE`, `REVERSION_AND_MOMENTUM`, `STATISTICAL`, `CROWDING`, `FAST`, `SLOW`, `MARKET`, `SECTOR`, `INDUSTRY`, `SUBINDUSTRY`, `SLOW_AND_FAST`
- GLB / EUR / ASI: the same list plus `COUNTRY`
- MEA: `NONE`, `MARKET`, `SECTOR`, `INDUSTRY`, `SUBINDUSTRY`, `COUNTRY`

## Other Settings

- Language: `PYTHON`, `FASTEXPR`
- Decay: integer `0..512`
- Truncation: float `0..1`
- Lookback: integer `0..1024`
- Selection handling: `POSITIVE`, `NON_ZERO`, `NON_NAN`
- Selection limit: integer `10..1000`
- Pasteurization: `ON`, `OFF`
- Unit handling: `VERIFY`
- NaN handling: `ON`, `OFF`
- Max trade / max position: `OFF`, `ON`
- Test period: `P0Y0M0D..P6Y0M0D`

## Captured UI Default

USA / TOP3000 / D1, subindustry neutralization, decay 4, truncation 0.08, pasteurization ON, unit handling VERIFY, NaN handling OFF, one year, max trade OFF, max position OFF. This is a UI baseline and must not override the live OPTIONS schema.
