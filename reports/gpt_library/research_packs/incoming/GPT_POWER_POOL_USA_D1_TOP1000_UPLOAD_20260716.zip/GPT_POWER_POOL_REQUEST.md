﻿# USA/D1 Power Pool July'26 2 - GPT Research Request

## Theme

- Theme: USA/D1 Power Pool July'26 2
- Window: 12 Jul 2026 through 26 Jul 2026
- Multiplier: 1X for regular power pool alphas

## Locked Simulation Scope

- Region: USA
- Delay: 1
- Universe: TOP1000
- Required test: High Turnover: High Turnover returns ratio

## Dataset Boundary

- PV1 is prohibited. Do not use pv1 fields, price/volume fields, or inst_pnl.
- The attached field files are a USA/D1/TOP3000 source snapshot selected for retrieval. They are not proof of TOP1000 availability.
- Before each candidate is emitted, validate every field in BRAIN under the locked USA/D1/TOP1000 settings. Reject unavailable fields; do not substitute an unverified field.
- Use only attached non-PV1 datasets and only listed operators.

## Research Task

For each theme below, select 10-20 real fields from the attached files and return field id, dataset, type, description, coverage, source region/universe/delay, and TOP1000 validation status.

- analyst estimate revisions and earnings surprises
- point-in-time fundamental quality and accounting changes
- model forecasts, factor projections, and cross-sectional quality
- news sentiment revisions and disagreement

Propose at most three type-compatible expression skeletons per theme. Check MATRIX/VECTOR/GROUP/scalar compatibility before producing each expression. Favor high-turnover-compatible formulations: timely changes, shorter lookbacks where justified, and no unnecessary smoothing. The required High Turnover returns-ratio test is a platform acceptance test, not an operator guarantee.

## Required Output

Return a compact table with: selected fields, expressions, operators, settings key, estimated operator count, PV1 check, TOP1000 field validation, and CANDIDATE or REJECTED status. State rejection reasons explicitly.

This is read-only research material. Do not submit simulations, alphas, or Osmosis points.
