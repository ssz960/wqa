﻿# Power Pool Context

This package is a constrained derivative of GPT_PROBE_UPLOAD_20260716.zip for the USA/D1 Power Pool July'26 2 theme.

- Selected non-PV1 fields: 10883
- Selected datasets: ai_equity_alpha, ai_news_scores, analyst4, analyst15, fundamental6, fundamental23, model77
- Source field snapshot: USA / D1 / TOP3000
- Target simulation settings: USA / D1 / TOP1000
- Field-scope caveat: source records must be revalidated in BRAIN at TOP1000 before use.
- Prohibited dependency: PV1, including inst_pnl.
- Required acceptance focus: High Turnover returns ratio test.

The copied probe_context_current.md and egion_settings_current.md retain source capability information. Where they show TOP3000 or a UI default, this theme file and GPT_POWER_POOL_REQUEST.md take precedence.
