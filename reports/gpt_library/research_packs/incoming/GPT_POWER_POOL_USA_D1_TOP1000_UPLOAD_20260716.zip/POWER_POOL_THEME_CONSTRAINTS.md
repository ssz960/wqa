﻿# USA/D1 Power Pool July'26 2 - Theme Constraints

## Mandatory Settings

| Setting | Required value |
|---|---|
| Region | USA |
| Delay | 1 |
| Universe | TOP1000 |
| Acceptance requirement | High Turnover returns ratio test |

## Hard Exclusions

- Do not use the PV1 dataset except platform-designated support fields. This package contains no PV1 file.
- Do not use inst_pnl, because the operator context identifies it as PV1-dependent.
- Do not infer TOP1000 field permission or coverage from the USA/D1/TOP3000 source snapshot.

## Validation Order

1. Lock USA/D1/TOP1000 settings.
2. Validate field availability in that scope.
3. Validate field/operator type compatibility.
4. Reject PV1-dependent content.
5. Backtest only after the read-only research output passes review.

No alpha submission is authorized by this package.
